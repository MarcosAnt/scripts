<?php
	$footer=
	'<footer>
		<div style="text-align: center;">
			<p style="margin-bottom: 0.5cm;">
				<a href="sobre_o_site.php" style="margin-right: 40px;color: #383838"> <b> Sobre o site </b> </a>
				<a href="mapa_do_site.php" style="margin-right: 40px;color: #383838"> <b> Mapa do site </b> </a>
				<a href="duvidas_frequentes.php" style="margin-right: 40px;color: #383838"> <b> Dúvidas frequentes </b> </a>
				<a href="contato.php" style="margin-right: 40px;color: #383838"> <b> Contato </b> </a>
			</p>
		</div>
	</footer>';
?>